export class Customer {
    
    constructor(
   // public id: number,
    public account_name: string,
    public company_name: string,
    public inspecter_name: string,
    public site_name: string,
    public ct: number,
    public mt: number

  ) {  }
}